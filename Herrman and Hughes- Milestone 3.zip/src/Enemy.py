class Enemy():
    def __init__(self, health, speed):
        self.health = health
        self.speed = speed
        
    def takeDamage(self, spell):
        self.health -= spell.damage
        
    def path_to_pos(x, y):
        x = x
    
    def die():
        y = y
    